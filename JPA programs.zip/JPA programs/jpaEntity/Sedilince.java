Import Jesa
Impet java.in Ca Sedilince
public static void main(String Livs)
try Class.forName("oracle.jdbc.driver.OracleDrive
10 Connection = DriverManager.getConnection therasiet Statements c.createStatement()
S.executeUpdatel create sequence jpases increment by 1 start with 200
//s.executeUpdate("drop table emp22 //s.executeUpdate("create table emp22(id number)" };
//s.executeUpdate("insert into emp22 values(se2030.extaly)
s.close();
catch(Exception e) (System.out.println(e