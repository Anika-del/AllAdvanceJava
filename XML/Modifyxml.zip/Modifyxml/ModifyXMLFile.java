
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;
import org.jdom.Document;

public class ModifyXMLFile
{
 public static void main(String ram[])
 {
	 try{
		 SAXBuilder builder=new SAXBuilder();
		 File xmlFile=new File("file.xml");
		 Document doc=(Document)builder.build(xmlFile);
		 Element rootNode=doc.getRootElement();
		 //update staff id attribute
		 Element staff=rootNode.getChild("staff");
		 staff.getAttribute("id").setValue("4");
		 //add new age element
		 Element age=new Element("age").setText("20");
		 staff.addContent(age);
		 //upade salary value 
		 staff.getChild("salary").setText("10000");
		 //remove firstname element 
		 staff.removeChild("lastname");
		 XMLOutputter xmlOutput=new XMLOutputter();
		 xmlOutput.setFormat(Format.getPrettyFormat());
		 xmlOutput.output(doc,new FileWriter("file9.xml"));
		 //xmlOutput.output(doc,System.out);
		 
		 System.out.println("file update!..");
	 }catch(IOException io)
	 {
		 io.printStackTrace();
	 }catch(JDOMException e)
	 {
		 e.printStackTrace();
	 }
 }
}